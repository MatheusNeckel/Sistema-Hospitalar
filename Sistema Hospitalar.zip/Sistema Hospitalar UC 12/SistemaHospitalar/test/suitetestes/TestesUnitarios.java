/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package suitetestes;

import javax.swing.JTextField;
import modelo.Paciente;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import visao.Menu;
import static org.junit.Assert.*;
import visao.GuiCadPaciente;

/**
 *
 * @author 55549
 */
public class TestesUnitarios {

    private Paciente pac;
    private GuiCadPaciente cadPaciente;

    public TestesUnitarios() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testeCPFValido() {
        JTextField campoCPF1 = new JTextField();

        campoCPF1.setText("12345678912");

        assertTrue("CPF tem 11 caracteres", campoCPF1.getText().length() == 11);
    }

    @Test
    public void testeCPFInvalido() {
        JTextField campoCPF1 = new JTextField();

        campoCPF1.setText("123456789123");

        assertFalse("CPF tem mais de 11 caracteres", campoCPF1.getText().length() == 11);
    }

    @Test
    public void testeEnderecoValido() {
        JTextField campoEndereco = new JTextField();

        campoEndereco.setText("Rua Fictício, Bairro Fictício");

        assertTrue("Endereço válido, dentro do limite de 200 caracteres", campoEndereco.getText().length() <= 200);
    }

    @Test
    public void testeEnderecoInvalido() {
        JTextField campoEndereco = new JTextField();

        campoEndereco.setText("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                + "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                + "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                + "xxxxxxxxxxxxxxxxxxxxxxxx");

        assertFalse("CPF tem mais de 200 caracteres", campoEndereco.getText().length() == 200);
    }

    @Test
    public void testaCPFsIguais() {
        String CPF1 = "12345678912";
        String CPF2 = "12345678913";
        assertNotEquals(CPF1, CPF2);
    }
}
